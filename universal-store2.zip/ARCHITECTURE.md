# THE UNIVERSAL STORE — Finalized Architecture

This supersedes the draft plan's open questions with your locked-in
decisions. Sections below map to what you asked to see before I started
implementation.

## 1. Final Architecture

Unchanged from the draft in its core shape — one Next.js (App Router,
TypeScript) app on Vercel, Supabase for Postgres/Auth/Storage/Realtime,
thin swappable adapters at every external boundary. What's now concrete
instead of open:

- **Payments:** dual-provider from day one — Paystack and Flutterwave both
  live behind a `PaymentProvider` interface, with a router that picks a
  provider per country/currency and refuses to silently fall back to a
  provider that doesn't actually support the requested currency (see §4).
- **Email:** Resend, behind a `sendEmail()` wrapper — nothing else imports
  the Resend SDK directly.
- **Exchange rates:** pluggable `ExchangeRateProvider`, default wired to
  exchangerate.host. Every order snapshots the USD→display-currency rate
  it used onto `orders.exchange_rate_snapshot` at creation time, so a
  later rate refresh never changes a historical order's displayed total.
- **Tax:** a `tax_rules` table (country/region → rate) plus a checkout-time
  lookup, not a hard-coded worldwide table — swappable for a dedicated tax
  API later without changing the checkout flow's shape.
- **Domain:** none yet. `NEXT_PUBLIC_SITE_URL`, the Google OAuth redirect,
  and both payment providers' webhook URLs all point at the Vercel-assigned
  URL for now — every place that will need updating when a domain is
  connected is called out in `README.md`.

## 2. Final Database Schema

Unchanged in shape from the draft plan (see the original architecture
message for the full table-by-table breakdown), with three additions to
reflect the decisions above:

- `orders.exchange_rate_snapshot numeric` — the rate captured at order
  creation (see above).
- `payments.provider` is now a `payment_provider` enum (`paystack` |
  `flutterwave`), and `payments.currency_code` records the currency
  actually charged/settled, which may differ from `orders.currency_code`
  (display) when a provider settles in something other than the
  customer's display currency.
- `tax_rules(country_code, region, rate_percent, is_active)` — new table
  for the configurable tax module.

Full DDL is in `supabase/migrations/0001_init_schema.sql` (schema) and
`0002_rls_policies.sql` (RLS), both included in this delivery and ready to
apply via `supabase db push` or the SQL editor.

## 3. Final Application Folder Structure

Matches the draft plan's structure exactly, now populated with real files
instead of a proposal — see the repo tree in this delivery. `lib/payments/`
has `paystack/` and `flutterwave/` adapter folders (no `stripe/` yet — add
one the same way if you introduce a third provider later). `lib/suppliers/`
has `cj/`, scaffolded but not wired to live endpoints (see §5).

## 4. Payment-Provider Abstraction

`lib/payments/types.ts` defines the `PaymentProvider` contract:
`supportedCurrencies()`, `createPaymentSession()`, `verifyPayment()`,
`verifyWebhookSignature()`, `refund()`. Both `lib/payments/paystack/client.ts`
and `lib/payments/flutterwave/client.ts` implement it against each
provider's stable, documented REST API (Paystack's bearer-token
`/transaction/initialize` + `/transaction/verify` flow; Flutterwave's v3
`/payments` + `/transactions/verify_by_reference` flow) — both files flag
inline exactly which details to reconfirm against live docs before
go-live (mainly: which currencies your specific merchant accounts are
approved to settle in, since that's controlled on the provider's side).

`lib/payments/router.ts` selects a provider per country, falling through a
priority list, and **only** returns a provider that declares support for
the requested currency — if nothing matches, it throws
`UnsupportedPaymentRouteError` rather than letting checkout proceed with a
provider that will fail. The priority table is a code default for now;
Phase 10 moves it into the `settings` table so you can reorder or add
providers (Stripe, etc.) from the admin without a deploy.

Webhook handlers (`app/api/webhooks/paystack/route.ts`,
`app/api/webhooks/flutterwave/route.ts`) verify the signature, record the
event in `webhook_events` for idempotency before processing, and hand off
to `markOrderPaidFromWebhook()` — which **re-verifies the payment against
the provider's API directly** rather than trusting the webhook payload
alone, before touching `orders.payment_status`.

## 5. Supplier Abstraction

`lib/suppliers/types.ts` defines five focused contracts (`ProductProvider`,
`InventoryProvider`, `ShippingProvider`, `FulfillmentProvider`,
`TrackingProvider`), composed into one `Supplier` interface.
`lib/suppliers/cj/auth.ts` implements **real, verified** CJ API 2.0
authentication — a single API key exchanged for an access/refresh token
pair (`POST /authentication/getAccessToken`), cached in a service-role-
only `supplier_tokens` table, and refreshed automatically as it nears
expiry (`POST /authentication/refreshAccessToken`), all confirmed against
CJ's current published docs before writing any of it. `lib/suppliers/cj/client.ts`'s
`request()` helper uses that token on every call via the `CJ-Access-Token`
header. The **business** methods (`searchProducts`, `submitOrder`, etc.)
still throw a clear `CjNotConfiguredError` — each one gets implemented
only once its own specific request/response contract is pulled from CJ's
docs, the same way auth was, not guessed.

## 6. Required Environment Variables

See `.env.example` in this delivery. `CJ_API_KEY` is now the only CJ
credential needed (the auth flow is single-key based, not email+key as
originally assumed before checking CJ's actual docs). Every variable is
commented with whether it's public or server-only.

## 7. Setup Steps for Each External Service

See `README.md` in this delivery — numbered, exact steps for Supabase,
Google OAuth, CJdropshipping, Paystack, Flutterwave, Resend, the exchange
rate provider, and Vercel (including the cron configuration in
`vercel.json`).

## 8. Development Phases — status

- ✅ **Phase 1 (project architecture)** — repo scaffold, Tailwind/design
  tokens, folder structure, `.gitignore`, `vercel.json`.
- ✅ **Phase 2 (database schema)** — full migrations + RLS policies, ready
  to apply, plus a profile-creation trigger on new `auth.users` rows.
- ✅ **Phase 3 (authentication)** — email/password signup+login, Google
  OAuth (button + `/auth/callback` exchange), email verification (via
  Supabase's built-in flow), forgot/reset password, sign out, and the
  post-signup "Where are you shopping from?" country/currency onboarding
  step (Section 4), all as Server Actions with a minimal protected
  `/account` page to confirm the session round-trips correctly.
- ✅ **Phase 4 (storefront shell)** — header with desktop nav + mobile
  drawer + real logo, footer, full homepage (real hero banner, trust bar,
  DB-driven category rail, featured/new-arrivals/bestsellers rails).
- ✅ **Phase 5 (products/categories)** — DB-driven PLP (`/shop`, with
  sort + quick filters), category index + detail pages, search, and a
  full PDP (gallery, variant selection, price/compare-at/rating, related
  products). Destination availability is looked up per product/country
  from `product_destination_availability` and **never assumed available**
  when no row exists yet — this is where hard constraint #2 is enforced
  today, ahead of CJ being wired in.
- ✅ **Phase 6 (cart/wishlist)** — server-validated cart, persistent
  account-only wishlist with move-to-cart, both re-validating product/
  variant status and stock server-side on every mutation. Guest→account
  cart merge on login now re-validates every line and drops anything
  invalid rather than trusting the guest cart's contents (see Phase 7 log
  below — this was hardened as a Phase 7 prerequisite).
- ✅ **Phase 7 (checkout/payment)** — full checkout flow: shipping address
  form → server-side re-derivation of every price/tax/shipping/currency
  figure via `getCheckoutSummary()` → payment-provider routing → order +
  payment session creation → redirect to the provider's hosted checkout.
  Idempotency key (generated once per checkout page load) prevents a
  double-click, refresh, or retried request from creating a second order
  or a second charge — a repeat lands back on the *same* order's status
  page instead. Webhook handlers now reconcile **every** event (not just
  ones that look like success) by re-verifying against the provider's API
  directly, so failed/cancelled payments correctly move the order to
  `payment_status = 'failed'` instead of leaving it stuck pending forever.
  Amount/currency mismatches between what was requested and what the
  provider confirms still mark the order paid (money was genuinely
  received) but raise an explicit admin notification for manual review.
- **Phases 8–15** unchanged from the draft plan's ordering, with pieces
  of Phase 8 (order history), Phase 9 (CJ auth), and Phase 10 (admin
  notifications) pulled forward this pass — see the update below.

### Testing
Unit/integration tests exist under `lib/**/__tests__/` against an
in-memory fake Supabase client and mocked payment providers (see
`test/helpers/fakeSupabase.ts`) — no live database or credentials
needed. Coverage: server-side price/quantity/destination validation
(manipulated client values are rejected), payment routing for
unsupported currency/country, webhook reconciliation (paid/failed/
pending/mismatch/duplicate), checkout idempotency (retried submission →
same order, never a duplicate charge), and guest→account cart merge
(empty account cart, overlapping-product merge, invalid-item drop).
**I wrote and traced these tests by hand but could not execute `npm
install`/`npm test` in this sandboxed environment — no network access.**
Run `npm test` after installing dependencies to get a real pass/fail
signal before trusting this code in production; treat it as
"implemented, awaiting your own execution" rather than "tested," per
the completion rubric.

## 9. Business Requirements Update

Applied this pass, on top of everything above:

- ✅ **Content pages** — About (your business description, explicitly
  states worldwide delivery), Contact (prominent "Chat with us on
  WhatsApp" button — the number is embedded only in the `wa.me` link,
  never rendered as visible text — plus email/social links that stay
  hidden until configured), Shipping Policy and Returns & Refunds Policy
  (written around how CJ's fulfillment network actually operates —
  typical 7–20 day international ranges, why physical returns to the
  supplier aren't practical, the 14-day damaged/wrong-item window and
  45–60 day lost-order window — not invented figures, sourced from CJ's
  public shipping/refund documentation and reworded for this store),
  Privacy Policy and Terms of Service (written specifically for what
  this app actually does — Supabase for data, Paystack/Flutterwave for
  payment, CJ for fulfillment, Resend for email — using CJ's own
  policies only as a reference for structure, not copied). **FAQ page
  removed entirely**, including its footer link, per your instruction.
- ✅ **Contact info is configurable, not hard-coded** — `settings.contact_info`
  (read via `lib/services/settings.ts`) holds the WhatsApp number, email,
  and social links; adding an email or social link later is a data
  change, not a page rebuild. Seeded for real (not demo) via the new
  `supabase/seed/business_config.sql` — **please double-check the
  WhatsApp number I used (`2349123100767`, from `wa.me/2349123100767`)
  against what you actually intended**, since your message had a
  formatting artifact around it that I had to interpret.
- ✅ **Customer order history** — `/account/orders` (list, real data,
  converts each order's stored USD total to its display currency using
  the snapshotted exchange rate rather than mislabeling raw USD as NGN/
  EUR) and `/account/orders/[id]` (full detail: status timeline derived
  from the three independent status fields, shipping address, tracking
  events if a shipment exists, itemized totals).
- ✅ **Admin notifications dashboard — fully active.** `/admin` (gated by
  `requireAdmin()`, not just RLS) shows real order/payment metrics
  (zeros when there's genuinely no data yet — never placeholder numbers)
  plus a recent-activity preview; `/admin/notifications` lists every
  `admin_notifications` row with an unread indicator, an all/unread
  filter, a "mark as read" action per row and a "mark all as read"
  action, and a deep link to the referenced order where one can be
  parsed from the notification text. One known gap: `admin_notifications`
  has no `entity_id` column, so that order link is regex-matched off the
  `TUS-######` pattern in the title/body rather than a real foreign key —
  works today, but a future migration adding `entity_type`/`entity_id`
  to that table would be more robust.
- ✅ **CJ authentication implemented for real** — see Section 5 above.
  This is the first CJ code in the project that isn't scaffolded; I
  fetched and read CJ's current API 2.0 auth documentation before
  writing it, per your explicit instruction not to invent endpoints.
- ✅ **Currencies constrained to NGN, USD, EUR** — `SupportedCurrency`,
  both payment adapters' `supportedCurrencies()`, the exchange-rate
  service's quote list, and the demo `countries` seed all updated
  together so nothing can silently drift back to GBP/CAD/AUD. The
  currency architecture itself didn't need to change to do this — it was
  already a type union + per-provider declared-support list, so adding a
  4th currency later is still "add one literal, update two provider
  arrays, seed one country," never a checkout rewrite.

### Still open
- The bracketed placeholders in Privacy/Terms (`[date]`, governing-law
  jurisdiction) — I didn't invent a jurisdiction or company legal name
  since I don't know your registered entity; fill those in, and please
  have both pages reviewed by a lawyer before launch — I'm not one, and
  policy pages carry real legal weight.
- `/admin` doesn't yet have order/product/customer management beyond the
  notifications feed and the overview metrics (Phase 10's full scope).
- CJ's business endpoints (product import, freight calc, order
  submission, tracking) — auth is real, everything past it is still
  scaffolded pending their own documented contracts.
- Live credentials in `.env.local`, including your real `CJ_API_KEY` and
  Paystack/Flutterwave **test-mode** keys — nothing above runs against a
  real provider until those are set.
- Generated Supabase TypeScript types for full query type-safety —
  cosmetic/DX, not a correctness issue.
