# THE UNIVERSAL STORE — Project Handoff

Status as of this document: mid-build, real checkout/payment/auth working end
to end against seeded data, CJ integration half-wired (auth + API client done,
not yet connected to admin UI or automatic order flow). Written for a
developer or AI with no access to the conversation that produced this code —
everything needed to continue should be here or linked from here.

---

## 1. What this is

**THE UNIVERSAL STORE** — "One Store. Everything You Need." — a real,
independent international ecommerce/dropshipping platform (not a Shopify
storefront). Own database, own auth, own admin, own business logic. Products
are sourced via CJdropshipping; the owner sets margins and controls what's
published.

Business description (use verbatim on the About page — already there):
> THE UNIVERSAL STORE is a global online shopping store offering a wide range
> of quality products across multiple categories at competitive prices... We
> carefully source our products through trusted dropshipping and fulfillment
> partners... THE UNIVERSAL STORE serves customers worldwide, with products
> and shipping options available based on destination and supplier
> availability.

Primary market: United States. Serves customers worldwide where CJ
availability and payment infrastructure allow. Currencies: **NGN, USD, EUR
only** — do not add GBP/CAD/AUD without the owner's explicit sign-off (this
was a deliberate correction from an earlier, wrong assumption).

---

## 2. Tech stack

- **Frontend/backend**: Next.js 15 (App Router), TypeScript, React 19,
  Tailwind CSS. Server Actions for all mutations. No separate backend
  service — Route Handlers + Server Actions running on Vercel are the
  backend.
- **Database/Auth**: Supabase (Postgres, Auth, Storage, Realtime). Row Level
  Security everywhere; a service-role client bypasses RLS for trusted
  server-only operations (webhooks, cron, admin actions already gated by
  `requireAdmin()`).
- **Supplier**: CJdropshipping, via a `Supplier` interface
  (`lib/suppliers/types.ts`) so a second supplier could be added later
  without touching checkout/orders/DB shape.
- **Payments**: Paystack + Flutterwave behind a `PaymentProvider` interface
  (`lib/payments/types.ts`), routed by country/currency
  (`lib/payments/router.ts`). Adding Stripe later = one new adapter file.
- **Email**: Resend (`lib/email/service.ts` — transport only, templates not
  yet written).
- **Exchange rates**: pluggable (`lib/currency/service.ts`), default wired to
  exchangerate.host, USD is the internal base currency everywhere.
- **Hosting**: Vercel, no custom domain yet (uses the Vercel-assigned URL —
  `NEXT_PUBLIC_SITE_URL` is the one place that changes when a domain is
  added).
- **Testing**: Vitest, with a hand-rolled in-memory fake of the Supabase
  query builder (`test/helpers/fakeSupabase.ts`) so service-layer logic can
  be unit-tested without a live database.

### Core architectural principles (do not violate these)
1. **Client never sets price/tax/shipping/currency/total.** Every checkout
   figure is re-derived server-side from the database at submission time
   (`lib/services/pricing.ts::validateCheckoutLines`,
   `lib/services/checkout.ts::getCheckoutSummary`).
2. **Display currency ≠ settlement currency**, tracked as separate DB
   columns (`orders.currency_code` vs `payments.currency_code`), with the
   exchange rate snapshotted per order (`orders.exchange_rate_snapshot`) so
   historical orders never change when rates move later.
3. **Never assume CJ can ship a product to a destination.** No row in
   `product_destination_availability` = treated as unavailable, not
   available. Never silently invent shipping cost/time.
4. **Payment success is only real once the provider's own API confirms it**
   (`lib/services/orders.ts::markOrderPaidFromWebhook` re-verifies via
   `provider.verifyPayment()`, never trusts the webhook payload or a browser
   redirect alone).
5. **Idempotency everywhere it matters**: order creation
   (`orders.idempotency_key`, client generates one key per checkout page
   load), payment webhooks (`webhook_events` unique on
   `(source, event_id)`), payment rows (`payments` unique on
   `(provider, provider_reference)`). CJ order submission idempotency is
   **designed but not yet wired** — see §7.
6. **Admin authorization is checked explicitly in code**
   (`lib/auth.ts::requireAdmin()`), never relied on via RLS alone, even
   though RLS also enforces it as defense-in-depth.
7. **True profit margin, not markup**:
   `selling_price = total_cost / (1 - margin/100)`
   (`lib/services/margin-pricing.ts::computeSellingPriceCents`). A 30%
   margin on $13 cost is $18.57, not $16.90 — this distinction was
   explicitly required by the business owner, don't "simplify" it back to a
   markup.
8. **Never invent third-party API behavior.** Every CJ/Paystack/Flutterwave
   endpoint implemented so far was read from that provider's current
   published docs before being coded — see §6 for exactly which CJ
   endpoints are verified vs. still scaffolded. **Do not guess CJ endpoint
   contracts.** Fetch and read
   `https://developers.cjdropshipping.cn/en/api/api2/api/*.html` (product,
   logistic, shopping, storage, webhook sections) before writing any new CJ
   call.
9. **No fake data presented as real.** `supabase/seed/demo_data.sql` is
   explicitly marked DEMO — every row prefixed `[DEMO]`, and the file has a
   large warning header. `supabase/seed/business_config.sql` is REAL
   business config (contact info) and is meant to run in production too.
   Admin metrics show honest zeros when there's no real data, never
   placeholder numbers.

---

## 3. Repository structure

```
app/
  (storefront)/          all customer-facing pages (route group, has header/footer via layout.tsx)
    page.tsx              homepage
    shop/, categories/, categories/[slug]/, search/, products/[slug]/
    cart/, wishlist/
    checkout/, checkout/return/
    account/{login,signup,forgot-password,reset-password,verify-email}/
    account/page.tsx      account overview
    account/orders/, account/orders/[id]/
    onboarding/country/
    about/, contact/, shipping/, returns/, privacy/, terms/   (no faq/ — removed on purpose)
  admin/                  admin dashboard (own layout, requireAdmin() gated)
    layout.tsx, page.tsx (overview), notifications/
    cj/page.tsx (CJ product search), cj/import/[pid]/page.tsx (preview + import)
  api/
    webhooks/{paystack,flutterwave}/route.ts
    cron/{refresh-rates,sync-inventory,poll-tracking}/route.ts   ⚠ sync-inventory/poll-tracking still call OLD stub CJ methods, need updating — see §7
    cron/retry-fulfillment/route.ts   NEW — re-attempts paid-but-unfulfilled orders, safe (idempotent)
  auth/callback/route.ts   OAuth code exchange
  icon.jpg, opengraph-image.jpg   real brand assets, Next.js auto-detected
lib/
  order-status.ts                    NEW — shared PaymentStatus/FulfillmentStatus/ShippingStatus types
  supabase/{server,client}.ts       server/browser Supabase clients
  auth.ts                           requireAdmin()/requireUser()
  constants.ts                      shared cookie names
  services/
    catalog.ts                      product/category listing, search
    cart.ts                         cart + guest→account merge (validates every line)
    wishlist.ts
    checkout.ts                     order creation + payment session, idempotent
    orders.ts                       webhook reconciliation, customer order reads, triggers fulfillment
    fulfillment.ts                  NEW — idempotent automatic CJ order submission
    cj-import.ts                    NEW — CJ search/preview/import, admin-gated
    pricing.ts                      checkout-time server-side line validation
    margin-pricing.ts               true-margin pricing engine (product→category→global)
    tax.ts                          configurable tax_rules lookup
    geo.ts                          shopper country/currency resolution
    activity.ts                     single write-path for activity_logs
    admin-notifications.ts          admin_notifications list/mark-read
    admin-metrics.ts                admin overview counts
    auth-actions.ts                 signup/login/logout/password reset/Google OAuth
    profile.ts                      country/currency preference
    settings.ts                     contact_info reader
    email/service.ts                Resend transport (no templates yet)
  currency/service.ts, types.ts     exchange rate fetch/cache/convert
  payments/
    types.ts                        PaymentProvider interface
    router.ts                       selectPaymentProvider() by country/currency
    paystack/client.ts, flutterwave/client.ts
  suppliers/
    types.ts                        Supplier interface (5 sub-contracts)
    cj/auth.ts                      REAL, verified CJ API 2.0 auth + token cache/refresh
    cj/client.ts                    REAL search/detail/freight/order/tracking methods — see §6 for exact status
    cj/status-mapping.ts            NEW — explicit CJ status → internal status mapping, never guessed
components/
  ui/                Button, Field (design-system primitives)
  storefront/         Header, Footer, Hero, ProductGrid, CheckoutForm, OrderStatusTimeline, etc.
  admin/              NotificationRow, MarkAllReadButton, CjSearchPanel (NEW), CjImportForm (NEW)
supabase/
  migrations/         0001–0006, apply in order (see §5)
  seed/
    demo_data.sql      DEMO ONLY — 2 fake products, do not run against production
    business_config.sql  REAL — contact info, safe/intended for production
test/helpers/fakeSupabase.ts   in-memory Supabase fake for unit tests
lib/**/__tests__/*.test.ts     test suites — see §8, NONE have been executed yet
ARCHITECTURE.md      earlier architecture-plan document from this build (historical, verbose)
README.md            setup steps per external service
.env.example          every env var, commented public vs. server-only
```

---

## 4. Database (migrations 0001–0006, apply in this order)

- **0001_init_schema.sql** — full normalized schema: profiles, addresses,
  countries, currency_rates, suppliers, categories, products,
  product_variants, product_images, product_destination_availability,
  reviews, supplier_sync_logs, carts, cart_items, wishlist_items, orders,
  order_items, payments, supplier_orders, shipments, tracking_events,
  coupons, tax_rules, notifications, activity_logs, admin_notifications,
  webhook_events, integration_logs, settings. All money in integer cents,
  USD base.
- **0002_rls_policies.sql** — RLS on every table, `is_admin()` security-definer
  helper, owner-scoped policies for user data, admin-only for system tables.
- **0003_profile_trigger.sql** — auto-creates a `profiles` row on new
  `auth.users` insert (covers email/password and Google OAuth alike).
- **0004_order_idempotency.sql** — `orders.idempotency_key` (partial unique
  index).
- **0005_supplier_tokens.sql** — `supplier_tokens` table for CJ's
  access/refresh token cache. **RLS enabled with zero policies** —
  unreachable from anon/authenticated roles under any circumstance, only
  the service-role client can touch it.
- **0006_pricing_engine.sql** — `categories.margin_override_percent`,
  `products.margin_override_percent`, `products.supplier_shipping_cost_cents`,
  `products.supplier_cost_updated_at`, `products.supplier_sync_status`,
  `product_variants.supplier_cost_synced_at`, order_items snapshot columns
  (`supplier_shipping_cost_cents`, `margin_percent_used`,
  `gross_profit_cents`), `supplier_orders.logistic_name` /
  `.cj_order_status` / `.cj_sub_status`, and seeds `settings.pricing_rules`
  with `default_profit_margin_percent: 30`.

Run via `supabase db push` or paste into the SQL editor in numeric order.
Then run `supabase/seed/business_config.sql` (real) and, for local dev only,
`supabase/seed/demo_data.sql` (fake — never run against production).

---

## 5. What's fully implemented (working, wired end-to-end)

- **Auth**: email/password + Google OAuth signup/login, email verification,
  forgot/reset password, sign-out, post-signup country/currency onboarding.
- **Storefront**: header/footer/homepage with the real logo + hero banner
  (`public/brand/logo.jpg`, `public/brand/hero-banner.jpg`), PLP with
  sort/quick-filters, category pages, search, PDP with variant selection and
  an honest per-destination shipping-availability block.
- **Cart/wishlist**: server-validated add/update/remove, guest cart via
  cookie, **guest→account merge on login** that re-validates every line and
  drops anything invalid rather than trusting the guest cart blindly (see
  `lib/services/cart.ts::mergeGuestCartIntoUser`).
- **Checkout/payment**: full flow — address form → server-recomputed
  summary (subtotal/shipping/tax/total, USD base + display-currency
  conversion) → provider routing (Paystack for NGN, Flutterwave for
  USD/EUR, throws a clean error if nothing supports the requested
  currency/country) → order + payment-session creation, idempotent against
  double-submit/retry → redirect to the provider's hosted checkout →
  webhook reconciliation that re-verifies against the provider's own API
  and explicitly handles paid/failed/pending/mismatch, never just "success
  or nothing."
- **Order history**: `/account/orders` (list, correct display-currency
  conversion using the snapshotted rate) and `/account/orders/[id]` (status
  timeline, shipping address, tracking events if a shipment row exists,
  itemized totals).
- **Admin notifications dashboard**: `/admin` (real metrics, honest zeros)
  and `/admin/notifications` (list, unread indicator, all/unread filter,
  mark-read/mark-all-read, deep link to the referenced order parsed from
  the `TUS-######` pattern in the notification text — **note**:
  `admin_notifications` has no real foreign key to the order, this is
  regex-based; a future migration adding `entity_type`/`entity_id` would be
  more robust).
- **Content pages**: About, Contact (prominent WhatsApp button — the number
  only ever appears inside the `wa.me` href, never as visible text —
  configurable via `settings.contact_info`), Shipping and Returns policies
  (grounded in CJ's actual fulfillment mechanics, not invented), Privacy and
  Terms (written for what this app actually does; has bracketed
  placeholders for `[date]` and governing-law jurisdiction — **do not fill
  these in with invented values**, the business owner needs to supply
  them, and both pages should get a real lawyer's review before launch).
  **No FAQ page** — removed intentionally, don't re-add one.
- **CJ authentication**: `lib/suppliers/cj/auth.ts` — real, verified against
  CJ's current API 2.0 docs. Single `CJ_API_KEY` → access/refresh token pair
  → cached in `supplier_tokens` → auto-refreshed near expiry. This is the
  only CJ code that's actually been checked against a live account (well,
  checked against docs — no live account has actually been exercised, see
  §9).
- **Pricing engine**: `lib/services/margin-pricing.ts` — true-margin
  formula, product→category→global override resolution, `previewPrice()`
  for admin UI to consume. Wired into checkout's order-item snapshot
  (`margin_percent_used`, `gross_profit_cents`,
  `supplier_shipping_cost_cents` all preserved per line at order time, per
  the "historical orders never change" requirement).
- **CJ product import**: `/admin/cj` (search) → `/admin/cj/import/[pid]`
  (preview with live margin-based price recompute) → import, with dedup by
  `supplier_product_id`, per-variant margin pricing, and automatic
  `product_destination_availability` population across every supported
  country via real CJ freight calculation. Imported products land as
  `status: 'draft'` — admin must explicitly publish (edit the row directly
  in the DB for now; no product-editor UI yet).
- **Automatic order fulfillment**: a paid order now actually gets submitted
  to CJ automatically (`lib/services/fulfillment.ts`), idempotently, with
  a 15-minute retry cron as a safety net, and an explicit CJ→internal
  status mapping layer (`lib/suppliers/cj/status-mapping.ts`) instead of
  ad-hoc status comparisons.

---

## 6. CJ integration — exact status (read this before touching CJ code)

**Implemented and verified against CJ's current docs:**
- Auth (`lib/suppliers/cj/auth.ts`) — `getAccessToken`/`refreshAccessToken`,
  fully real.
- `searchProducts()` → `GET /product/listV2` — real, returns `variants: []`
  (CJ's list response has no per-variant cost/inventory) — intentional, the
  admin preview step calls `getProduct()` next for full detail.
- `getProduct()` → `GET /product/query?pid=...` — real, full variant/cost/
  inventory breakdown. Variant option names derived by positionally zipping
  `productKeyEn.split("-")` with each variant's `variantKey.split("-")` —
  **spot-check this against a real CJ product** before trusting it broadly.
- `checkDestinationAvailability()` → `POST /logistic/freightCalculate` —
  real, picks the cheapest returned option.
- `submitOrder()` → `POST /shopping/order/createOrderV2` — real. Same
  caveats as before still apply and still matter for real money:
  - `CJ_ORDER_PAY_TYPE` env var (default `"2"` = balance payment) —
    **confirm the store's CJ account actually carries a balance** before
    trusting automatic fulfillment; `"1"` (page payment) is NOT automatic.
  - `sellPrice`/`variantSellPrice` is treated as our supplier cost —
    **unverified against a real CJ invoice.**
  - Assumes one shipment/logistics method per order (first item's route).
- `getTrackingUpdates()` / `getCjOrderDetail()` → `GET
  /shopping/order/getOrderDetail?orderId=...` — real.
- **`mapCjOrderStatus()`** (`lib/suppliers/cj/status-mapping.ts`) — **new
  this pass.** Explicit mapping from CJ's documented statuses (CREATED,
  IN_CART, UNPAID, PENDING, PROCESSING, UNSHIPPED [+ sub-status],
  SHIPPED, DELIVERED, CANCELLED) to this store's `fulfillment_status`/
  `shipping_status`. Anything unrecognized (including CJ's own "OTHER")
  returns `needsAdminReview: true` rather than guessing. Tested in
  `lib/suppliers/cj/__tests__/status-mapping.test.ts`.

**Explicitly NOT implemented (throws `CjNotConfiguredError`, on purpose):**
- `getInventory()` (single-variant) — no dedicated endpoint confirmed yet.
- `cancelOrder()` — CJ likely has an order-delete endpoint but its exact
  contract wasn't pulled. **Do not guess this** — read
  `https://developers.cjdropshipping.cn/en/api/api2/api/shopping.html`
  first.
- `getInventoryBulk()` works but inefficiently (N individual `product/query`
  calls, no dedicated bulk endpoint confirmed yet).

**Now built and connected (new this pass):**
- **Admin CJ product search/preview/import UI** — `/admin/cj` (search),
  `/admin/cj/import/[pid]` (preview: images, per-variant cost/stock,
  category picker with a live true-margin price preview that recomputes
  when the category changes, title/description override, import button).
  `lib/services/cj-import.ts`:
  - `searchCjProducts()` — wraps `cjProvider.searchProducts`, flags
    already-imported results.
  - `getCjProductPreview()` — wraps `cjProvider.getProduct`, checks for an
    existing import.
  - `previewImportPrice()` — live margin recompute for the UI.
  - `importCjProduct()` — the real import: **dedups by
    `supplier_product_id`** (refuses a second import outright), computes
    the base product price from the cheapest variant via
    `margin-pricing.ts`, **individually margin-prices every variant** and
    stores the difference as `price_delta_cents` (so each variant is
    correctly profitable, not just the cheapest one), imports images,
    stores `status: 'draft'` (admin must explicitly publish — matches the
    business acceptance criteria's separate "publish" step), and then
    **populates `product_destination_availability` for every
    currently-supported country** via real freight calculation
    (sequential with a ~1.1s delay between calls, respecting CJ's
    documented 1 req/sec limit). Failures at any step write an
    `admin_notifications` row, never fail silently.
  - **Not yet done**: no admin UI lists *already-imported* CJ products
    with sync status/last-synced time/fulfillment status (business
    requirement §16, "Admin CJ Dashboard") — only search/import exists,
    not a management view of what's already in the catalog.
  - **No tests yet** for search/preview/import/dedup logic.
- **Automatic order fulfillment** — `lib/services/fulfillment.ts::submitOrderToCj(orderId)`.
  Called inline from `markOrderPaidFromWebhook()` right after an order is
  marked paid (awaited, not fire-and-forget — serverless functions aren't
  guaranteed to keep running background work after the response is sent).
  Idempotent via a `supplier_orders` row **claimed before** the CJ API
  call — a second call for the same order short-circuits
  (`alreadySubmitted: true`) rather than double-submitting. On failure:
  `supplier_orders.status = 'failed'`, `last_error` set, an
  `admin_notifications` row raised, and **`orders.fulfillment_status` is
  never touched** (never falsely marked fulfilled). On success, applies
  `mapCjOrderStatus()`'s result to the order. A retry cron
  (`app/api/cron/retry-fulfillment`, every 15 min) re-attempts any paid
  order still sitting at `fulfillment_status = 'unfulfilled'` — safe
  because of the idempotency claim. Tested in
  `lib/services/__tests__/fulfillment.test.ts` (submission, idempotency,
  unpaid-order refusal, failure handling, missing-variant-mapping
  handling, retry-after-failure).

**Still genuinely missing:**
- **Admin pricing UI** — a settings page to edit the global default margin
  and category overrides, and a product editor with the cost/margin/
  selling-price preview panel (business requirements §12). The engine
  (`margin-pricing.ts`) is ready; nothing calls
  `setGlobalDefaultMarginPercent()` from a UI yet, and there's no way to
  set a *product's* `margin_override_percent` after import except directly
  in the database.
- **Admin CJ dashboard / management view** (business requirements §16) —
  `/admin/cj` only does search/import, no view of already-imported
  products, sync status, or an orders-awaiting-fulfillment pipeline.
- `cancelOrder()` — searched again for a confirmed CJ Open API 2.0
  order-cancellation contract, found nothing reliable (only an unrelated
  "CJ Affiliate" marketing API and dashboard-UI references came up).
  Still throws `CjNotConfiguredError`, per "don't fake it."
- Tests for CJ product search/import/dedup.

**Corrected from an earlier version of this document**: `sync-inventory`
was already calling the real `getInventoryBulk()` — an earlier pass of
this file wrongly said both crons were still stub-era. `poll-tracking`
*was* genuinely broken though, in a way worth knowing about: it was
inserting `supplier_orders.id` into `tracking_events.shipment_id` (the
wrong table's ID — that column references `shipments.id`), and nothing
anywhere created a `shipments` row in the first place. Both are fixed as
of this pass: `submitOrderToCj()` now creates the shipment, and
`poll-tracking` now finds/updates it correctly and applies
`mapCjOrderStatus()` to update order status, logging to
`supplier_sync_logs` like `sync-inventory` does.

---

## 7. Recommended build order for continuing

Updated after this pass — status mapping, product import, destination
availability at import, automatic fulfillment, and the cron fixes above
are now done. What's left, in priority order:

1. **Run `npm install && npm test && npm run build` for real** and send
   the output back — nothing in this project has ever been verified with
   a working `node_modules` tree; every check so far has been static
   reading/reasoning or a best-effort partial `tsc` run (see STEP_REPORT.md
   for exactly what that did and didn't cover).
2. **Admin pricing UI** — global margin settings + product editor with a
   live cost/margin/price/profit preview, built on the already-ready
   `margin-pricing.ts` engine.
3. **Admin CJ dashboard/management view** — list of imported products with
   CJ IDs, sync status, last-synced time, fulfillment status, CJ order
   reference, tracking, and a "failed operations" list surfaced from
   `admin_notifications`/`supplier_sync_logs`.
4. **Tests** for CJ product search/import/dedup (`cj-import.ts`),
   inventory sync, and tracking sync, using the established
   `test/helpers/fakeSupabase.ts` pattern.
5. **Run `npm install && npm test` for real** — nothing in this project's
   test suite (old or new) has ever actually been executed; see §8.
6. Fill in real `[date]`/jurisdiction values in Privacy/Terms once the
   business owner provides them (don't invent).
7. Confirm the WhatsApp number in `supabase/seed/business_config.sql`
   (`2349123100767`) and the `CJ_ORDER_PAY_TYPE`/CJ-balance assumption with
   the business owner — both are unverified assumptions, not confirmed
   facts.

---


## 8. Testing status — read this before trusting any "tests pass" claim

Test files exist and were written carefully (hand-traced against the fake
Supabase client's logic), but **they have never actually been executed** —
the environment they were written in had no network access to run `npm
install`/`npm test`. Treat every test file below as "implemented, awaiting
real execution," not "passing."

Existing suites:
- `lib/payments/__tests__/router.test.ts` — provider routing, unsupported
  currency/country.
- `lib/services/__tests__/pricing.test.ts` — server-side price/quantity/
  destination validation (manipulated client values rejected).
- `lib/services/__tests__/margin-pricing.test.ts` — true-margin formula,
  3-level override resolution.
- `lib/services/__tests__/cart.test.ts` — guest→account merge (empty
  account cart, overlapping-product merge, invalid-item drop).
- `lib/services/__tests__/orders.test.ts` — webhook reconciliation
  (paid/failed/pending/mismatch/duplicate).
- `lib/services/__tests__/checkout.test.ts` — order-creation idempotency,
  unsupported-route error handling.
- `lib/suppliers/cj/__tests__/status-mapping.test.ts` — every documented
  CJ status/sub-status combination, plus unrecognized-status handling.
- `lib/services/__tests__/fulfillment.test.ts` — automatic fulfillment
  submission, idempotency (no duplicate CJ order on a second call),
  unpaid-order refusal, failure handling (never falsely marks fulfilled),
  missing-CJ-variant-mapping handling, retry-after-failure.

**First real action item: run `npm install && npm test` and fix whatever
actually fails.** Don't assume any of this is correct just because the
logic was traced by hand.

---

## 9. The build error this document was written alongside

Vercel's build failed with:
```
./app/(storefront)/categories/page.tsx:21:28
Type error: Parameter 'category' implicitly has an 'any' type.
```
Root cause found: `lib/supabase/server.ts::createServiceRoleClient()` used
`const { createClient } = require("@supabase/supabase-js")` — a CommonJS
`require()` inside TypeScript, which resolves to an untyped `any`. That
`any` cascaded through every `.from().select()` call built on top of it
project-wide, which is what broke `.map()` type inference wherever a page
iterated over data fetched via the service-role client (not just the one
file the build happened to fail on first).

**Fix applied**: replaced the `require()` with a static
`import { createClient as createRawSupabaseClient, type SupabaseClient } from "@supabase/supabase-js"`
and gave the function an explicit `SupabaseClient` return type.

**This was NOT verified with a real build** (no network in the environment
that made this fix). It's the theoretically correct fix and should resolve
the whole class of implicit-any errors, but if the next Vercel build still
shows a similar error on some other file, apply the same diagnostic: find
what makes the source value untyped (usually a missing return type
annotation or another loose `require()`/dynamic import), fix that one spot
rather than patching each call site individually.

Longer-term proper fix (not done): generate real Supabase TypeScript types
(`supabase gen types typescript`) and pass them as the `Database` generic to
both `createClient()` and `createServiceRoleClient()`. That would give full
column-level type safety, not just "arrays are arrays." Worth doing once the
schema stabilizes.

---

## 10. Environment variables

See `.env.example` for the full list with comments. Summary of what's
actually required for what:

| Feature | Vars needed |
|---|---|
| App to boot at all | `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` |
| Google login | Configured in the Supabase dashboard, not env vars |
| CJ auth + business calls | `CJ_API_KEY` (single key, not email+key) |
| CJ order payment mode | `CJ_ORDER_PAY_TYPE` (optional, defaults to `"2"` = balance) |
| Paystack | `PAYSTACK_SECRET_KEY`, `NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY` |
| Flutterwave | `FLUTTERWAVE_SECRET_KEY`, `NEXT_PUBLIC_FLUTTERWAVE_PUBLIC_KEY`, `FLUTTERWAVE_ENCRYPTION_KEY`, `FLUTTERWAVE_WEBHOOK_SECRET_HASH` |
| Email | `RESEND_API_KEY`, `EMAIL_FROM_ADDRESS` |
| Exchange rates | `EXCHANGE_RATE_API_KEY`, `EXCHANGE_RATE_PROVIDER` |
| Cron auth | `CRON_SECRET` |
| Canonical URLs | `NEXT_PUBLIC_SITE_URL` (update when a custom domain is added) |

None of these are hard-coded anywhere in source. Never put a secret value in
a client component or a `NEXT_PUBLIC_` var.

---

## 11. What NOT to change without good reason

- Don't reintroduce GBP/CAD/AUD — currency set is a deliberate business
  decision (NGN/USD/EUR only).
- Don't remove the FAQ-page removal (i.e., don't add one back) — explicit
  business decision.
- Don't relax the "never assume CJ can ship" rule or the "no row = not
  available" default anywhere in the codebase, including in new sync code.
- Don't make Server Actions throw for *expected* validation failures (out
  of stock, unsupported currency, etc.) — return `{ success: false, error }`
  instead. Next.js redacts thrown Server Action errors to an opaque digest
  in production, which silently swallows the message the customer needs to
  see. This bit the project once already (see the pattern already used in
  `cart.ts`, `wishlist.ts`, `checkout.ts` — follow it for new code).
- Don't skip re-reading CJ's actual docs before implementing a new CJ
  endpoint, even one that seems obvious from the ones already done.

---

## 12. Setup / running locally

```bash
npm install
cp .env.example .env.local   # fill in values per §10
npm run dev
```

Full external-service setup steps (Supabase, Google OAuth, CJ, Paystack,
Flutterwave, Resend, exchange-rate provider, Vercel/cron) are in
`README.md` — they're accurate as of this document.
